// reducers.js
import { ADD_TODO, TOGGLE_TODO, DELETE_TODO, EDIT_TODO, SET_FILTER } from '../Actions/actions';
export const todoReducer = (state, action) => {
  switch (action.type) {
    case ADD_TODO:
      return [
        ...state,
        {
          // id: Date.now(),
          id: action.payload.id,
          text: action.payload.text,
          status: action.payload.status,
          completed: action.payload.status === 'incomplete',
          //completed: action.payload.status
        },
      ];
    case TOGGLE_TODO:
      return state.map(todo =>
        todo.id === action.payload.id ? { ...todo, completed: !todo.completed } : todo
      );
    case DELETE_TODO:
      return state.filter(todo => todo.id !== action.payload.id);
    case EDIT_TODO:
      return state.map(todo =>
        todo.id === action.payload.id
          ? { ...todo, text: action.payload.newText, status: action.payload.newStatus }
          : todo
      );
    default:
      return state;
  }
};

export const filterReducer = (state, action) => {
  switch (action.type) {
    case SET_FILTER:
      return action.payload.filter;
    default:
      return state;
  }
};
