// TodoApp.js

import React, { useReducer, useState } from 'react';
import { Modal, Button } from "react-bootstrap";
import Form from 'react-bootstrap/Form';
import 'bootstrap/dist/css/bootstrap.css';
import { addTodo, toggleTodo, deleteTodo, editTodo, setFilter } from '../Actions/actions';
import { todoReducer, filterReducer } from '../Reducers/todoReducer';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const TodoApp = () => {
    const [todos, dispatchTodos] = useReducer(todoReducer, []);
    const [filter, dispatchFilter] = useReducer(filterReducer, 'all');
    const [modalOpen, setModalOpen] = useState(false);
    const [newTodo, setNewTodo] = useState('');
    const [status, setStatus] = useState('incomplete');
    const [selectedTodo, setSelectedTodo] = useState(null);
    const [addTaskButtonKey, setAddTaskButtonKey] = useState(null);

    const openModalToAdd = () => {
        setSelectedTodo(null);
        setModalOpen(true);
        const uniqueKey = `addTask_${Date.now()}`;
        setAddTaskButtonKey(uniqueKey);
    };

    const openModalToEdit = todo => {
        setSelectedTodo(todo);
        setNewTodo(todo.text);
        setStatus(todo.status);
        setModalOpen(true);
    };

    const closeModal = () => {
        setSelectedTodo(null);
        setNewTodo('');
        setStatus('incomplete');
        setModalOpen(false);
    };

    const handleAddEditTodo = () => {
        if (selectedTodo) {
            const isExistingTask = todos.some(todo => todo.text !== newTodo);
            if (isExistingTask) {
                // Show a toast notification for duplicate task
                toast.error('Task already exists!', {
                    position: 'top-right',
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                });
                return;
            } else {
                dispatchTodos(editTodo(selectedTodo.id, newTodo, status));
                dispatchTodos(toggleTodo(selectedTodo.id));
            }
        } else {
            const isExistingTask = todos.some(todo => todo.text === newTodo);
            if (isExistingTask) {
                // Show a toast notification for duplicate task
                toast.error('Task already exists!', {
                    position: 'top-right',
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                });
                return;
            } else {
                dispatchTodos(addTodo(addTaskButtonKey, newTodo, status));
                dispatchTodos(toggleTodo(addTaskButtonKey));
            }
        }

        closeModal();
    }
    const handleDeleteTodo = (id) => {
        dispatchTodos(deleteTodo(id));
    };

    const handleToggleTodo = id => {
        dispatchTodos(toggleTodo(id));
    };

    const setTodoFilter = filter => {
        console.log("filter value: " + filter);
        dispatchFilter(setFilter(filter));
    };

    const filteredTodos = todos.filter(todo => {
        switch (filter) {
            case 'completed':
                return todo.completed;
            case 'incomplete':
                return !todo.completed;
            default:
                return true;
        }
    });

    const todoList = filteredTodos.map(todo => (
        <table style={{ borderCollapse: "collapse", width: "100%" }}>
            <tr>
                <td key={todo.id} style={{ padding: "8px", textAlign: "center", borderBottom: "1px solid #ddd" }}>

                    <div className="col">
                        <p style={{ display: "flex", alignItems: "left" }} >
                            <Form.Check type="checkbox"
                                checked={todo.completed}
                                onChange={() => handleToggleTodo(todo.id)}
                            />
                        </p>
                    </div>
                    <span
                        style={{
                            textDecoration: todo.completed ? 'line-through' : 'none',
                            marginRight: '10px',
                        }}
                    >
                        {todo.text}
                    </span>

                </td>
                <td style={{ padding: "8px", textAlign: "right", borderBottom: "1px solid #ddd" }}>
                    <Button style={{ marginRight: "10px" }} className="btn btn-success" onClick={() => openModalToEdit(todo)}>Edit</Button>
                    <Button className="btn btn-danger" onClick={() => handleDeleteTodo(todo.id)}>Delete</Button>
                </td>
            </tr>
        </table>
    ))

    return (
        <>
            <ToastContainer />
            <div>
                <div className="bg-light">
                    <div className="container py-5" >
                        <h1>TODO App</h1>
                        <table style={{ borderCollapse: "collapse", width: "100%" }}>
                            <tr>
                                <td style={{
                                    padding: "8px",
                                    textAlign: "center", borderBottom: "1px  #ddd"
                                }}>
                                    <Button key={addTaskButtonKey} className="navbar navbar-expand-lg navbar-light bg-dark" onClick={openModalToAdd}>Add Task</Button>
                                </td>
                                <td style={{ padding: "8px", textAlign: "right", borderBottom: "1px  #ddd" }}>
                                    <label>Filter: </label>
                                    <select onChange={e => setTodoFilter(e.target.value)} value={filter}>
                                        <option value="all">All</option>
                                        <option value="completed">Completed</option>
                                        <option value="incomplete">Incomplete</option>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        <Modal show={modalOpen} onHide={closeModal}>
                            <Modal.Header closeButton={closeModal}>
                                <Modal.Title>{selectedTodo ? 'Edit Task' : 'Add Task'}</Modal.Title>
                            </Modal.Header>
                            <Modal.Body>
                                <Form>
                                    <Form.Group>
                                        <Form.Label>Title</Form.Label>
                                        <Form.Control
                                            type="text"
                                            value={newTodo}
                                            onChange={e => setNewTodo(e.target.value)}
                                        />
                                    </Form.Group>
                                    <Form.Group>
                                        <Form.Label>Status</Form.Label>
                                        <Form.Control as="select" onChange={e => setStatus(e.target.value)} value={status}>
                                            <option value="incomplete">Incomplete</option>
                                            <option value="completed">Completed</option>
                                        </Form.Control>
                                    </Form.Group>
                                </Form>


                                <Modal.Footer>
                                    <Button variant="secondary" type="submit" onClick={handleAddEditTodo}>{selectedTodo ? 'Edit Task' : 'Add Task'}</Button>

                                    <Button variant="secondary" onClick={closeModal}>Cancel</Button>
                                </Modal.Footer>
                            </Modal.Body>
                        </Modal>
                        <div className="row">
                            <div className="col-8">
                                <section className="dl-blurbs">
                                    <div className="">
                                        <div className="card-body">
                                            {todoList}
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default TodoApp;