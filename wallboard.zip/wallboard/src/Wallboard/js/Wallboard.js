import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Modal, Button } from "react-bootstrap";
import { useCallback } from "react";
import Form from "react-bootstrap/Form";
import "bootstrap/dist/css/bootstrap.css";
import {
  fetchCampaigns,
  fetchCampUserData,
  fetchStatData,
} from "../../middleware/api";
import "../css/Wallboard.css";
import ReactPaginate from "react-paginate";

const Wallboard = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedCampaigns, setSelectedCampaigns] = useState([]);
  const dispatch = useDispatch();
  const campaigns = useSelector((state) => state.campaign.campaigns);
  const [historicalData, setHistoricalData] = useState([]);
  const [runtimeData, setRuntimeData] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 10;

  const getCurrentDateTimeIST = () => {
    const options = {
      timeZone: "Asia/Kolkata",
      hour12: true,
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      year: "numeric",
      month: "short",
      day: "numeric",
    };
    const formatter = new Intl.DateTimeFormat("en-IN", options);
    return formatter.format(new Date());
  };

  const [currentDateTime, setCurrentDateTime] = useState(
    getCurrentDateTimeIST()
  );

  useEffect(() => {
    if (modalOpen) {
      dispatch(fetchCampaigns());
    }
  }, [modalOpen, dispatch]);

  const fetchAllRuntimeData = useCallback(
    async (campaignId, campaignType, campaignName) => {
      try {
        const combinedData = await dispatch(
          fetchStatData({ campaignId, campaignType, campaignName })
        ).unwrap();
        setRuntimeData((prevData) => {
          const existingIndex = prevData.findIndex(
            (data) => data?.agentStatInfo?.[0]?.campaign_id === campaignId
          );
          if (existingIndex !== -1) {
            const newData = [...prevData];
            newData[existingIndex] = combinedData;
            return newData;
          } else {
            return [...prevData, combinedData];
          }
        });
        return { success: true, campaignId, combinedData };
      } catch (error) {
        console.error(
          `Failed to fetch runtime data for campaignId ${campaignId}, campaignType ${campaignType}, and campaignName ${campaignName}:`,
          error
        );
        return { success: false, campaignId, error };
      }
    },
    [dispatch]
  );
  const fetchAllcampaignUserData = useCallback(
    async (campaignId, campaignType, campaignName) => {
      try {
        const combinedData = await dispatch(
          fetchCampUserData({ campaignId, campaignType, campaignName })
        ).unwrap();

        setHistoricalData((prevData) => {
          const existingIndex = prevData.findIndex(
            (data) => data.campaignUserData[0]?.campaignId === campaignId
          );
          if (existingIndex !== -1) {
            const newData = [...prevData];
            newData[existingIndex] = combinedData;
            return newData;
          } else {
            return [...prevData, combinedData];
          }
        });
        // Fetch runtime data after successful campaign user data fetch
        await fetchAllRuntimeData(campaignId, campaignType, campaignName);

        return { success: true, campaignId, combinedData };
      } catch (error) {
        console.error(
          `Failed to fetch user data for campaignId ${campaignId}, campaignType ${campaignType}, and campaignName ${campaignName}:`,
          error
        );
        return { success: false, campaignId, error };
      }
    },
    [dispatch, fetchAllRuntimeData]
  );
  const fetchData_historical = useCallback(() => {
    selectedCampaigns.forEach(({ campaignId, campaignType, campaignName }) =>
      fetchAllcampaignUserData(campaignId, campaignType, campaignName)
    );
  }, [selectedCampaigns, fetchAllcampaignUserData]);

  const fetchData_runtime = useCallback(() => {
    selectedCampaigns.forEach(({ campaignId, campaignType, campaignName }) =>
      fetchAllRuntimeData(campaignId, campaignType, campaignName)
    );
  }, [selectedCampaigns, fetchAllRuntimeData]);

  useEffect(() => {
    const interval = setInterval(() => {
      fetchData_historical();
      setCurrentDateTime(getCurrentDateTimeIST());
    }, window.refreshIntervals.historical_intervals);

    return () => clearInterval(interval);
  }, [fetchData_historical]);

  useEffect(() => {
    const interval = setInterval(() => {
      fetchData_runtime();
      setCurrentDateTime(getCurrentDateTimeIST());
    }, window.refreshIntervals.stats_intervals);

    return () => clearInterval(interval);
  }, [fetchData_runtime]);

  const handleDone = () => {
    setHistoricalData((prevData) =>
      prevData.filter((data) =>
        selectedCampaigns.some(
          (campaign) =>
            campaign.campaignId === data.campaignUserData[0]?.campaignId
        )
      )
    );
    fetchData_historical();
    setRuntimeData((prevData) =>
      prevData.filter((data) =>
        selectedCampaigns.some(
          (campaign) =>
            campaign.campaignId === data?.agentStatInfo?.[0]?.campaign_id
        )
      )
    );
    fetchData_runtime();
    closeModal();
  };

  const openModalToAdd = () => {
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  const handleCheckboxChange = (campaignId, campaignType, campaignName) => {
    setSelectedCampaigns((prevSelected) => {
      const campaignExists = prevSelected.some(
        (campaign) =>
          campaign.campaignId === campaignId &&
          campaign.campaignType === campaignType &&
          campaign.campaignName === campaignName
      );

      if (campaignExists) {
        return prevSelected.filter(
          (campaign) =>
            campaign.campaignId !== campaignId ||
            campaign.campaignType !== campaignType ||
            campaign.campaignName !== campaignName
        );
      } else {
        return [...prevSelected, { campaignId, campaignType, campaignName }];
      }
    });
  };

  const uniqueAgentIds = new Set();
  const idleAgentIds = new Set();
  const breakAgentIds = new Set();

  console.log("combinedData wallboardjs runtimeData", runtimeData);
  console.log("combinedData wallboardjs historicalData", historicalData);

  let userCampaignData = {};

  // Processing historical data
  historicalData.forEach((data) => {
    if (data.campaignUserData) {
      data.campaignUserData.forEach((user) => {
        if (user.userId) {
          uniqueAgentIds.add(user.userId);

          // Initialize data for each user if not already present
          if (!userCampaignData[user.userId]) {
            userCampaignData[user.userId] = [];
          }

          // Add campaignId and userId to userCampaignData
          userCampaignData[user.userId].push({
            campaignId: user.campaignId,
            userId: user.userId,
          });

          if (
            user.onAutoCall &&
            user.working &&
            user.ready &&
            !idleAgentIds.has(user.userId)
          ) {
            idleAgentIds.add(user.userId);
          } else if (
            !user.onAutoCall &&
            !user.ready &&
            !breakAgentIds.has(user.userId)
          ) {
            breakAgentIds.add(user.userId);
          }
        }
      });
    }
  });
  let userTotalCalls = 0;
  let userTotalDuration = 0;
  const userCallData = [];
  const aggregateDataByCampaignAndUser = (data, campaignId, userId) => {
    data.forEach((item) => {
      // Filter by campaignId
      if (
        item.agentStatInfo &&
        item.agentStatInfo.some((stat) => stat.campaign_id === campaignId)
      ) {
        // Aggregate based on userId
        item.agentStatInfo.forEach((stat) => {
          console.log("NETU", stat);
          if (stat.user_id === userId && stat.campaign_id === campaignId) {
            userCallData.push({
              campaignId: stat.campaign_id,
              userId: stat.user_id,
              userTotalCalls: stat.userCampaignCallConnectedCount || 0,
              userTotalDuration: stat.userCampaignTalkTimeTotal || 0,
            });
          }
        });
      }
    });

    return userCallData;
  };

  // Process each user
  console.log(`Total userCampaignData:`, userCampaignData);
  Object.keys(userCampaignData).forEach((userId) => {
    userCampaignData[userId].forEach((entry) => {
      const aggregatedResults = aggregateDataByCampaignAndUser(
        runtimeData,
        entry.campaignId,
        userId
      );
      console.log(`User ${userId} for campaignId ${entry.campaignId}:`);
      console.log(`Total Duration:`, aggregatedResults.totalDuration);
      console.log(`Total Calls:`, aggregatedResults.totalCalls);
      userTotalDuration = aggregatedResults.totalDuration;
      userTotalCalls = aggregatedResults.totalCalls;
    });
  });

  const userCount = uniqueAgentIds.size;
  const idleAgents = idleAgentIds.size;
  const breakAgents = breakAgentIds.size;

  // Processing runtime data
  const processRuntimeData = useCallback(() => {
    let waitingCalls = 0;
    let onCalls = 0;
    let totalHoldCalls = 0;
    let totalWrappedCalls = 0;
    let totalMissedCalls = 0;

    runtimeData.forEach((data) => {
      // Check if waitingCallsInfo exists and is an array
      if (Array.isArray(data.waitingCallsInfo)) {
        data.waitingCallsInfo.forEach((call) => {
          if (call.status === "ringing" && call.ownerCrtObjectId === null) {
            waitingCalls += 1;
          } else if (call.status === "connected" && call.ownerCrtObjectId) {
            onCalls += 1;
          }
        });
      }

      // Check if agentStatInfo exists and is an array
      if (Array.isArray(data.agentStatInfo)) {
        data.agentStatInfo.forEach((agentStat) => {
          if (agentStat.holdCallsCount != null) {
            totalHoldCalls += agentStat.holdCallsCount;
          }
          if (agentStat.totalWrappedCalls != null) {
            totalWrappedCalls += agentStat.totalWrappedCalls;
          }
          if (agentStat.userCampaignCallDropCount != null) {
            totalMissedCalls += agentStat.userCampaignCallDropCount;
          }
        });
      }
    });

    return {
      waitingCalls,
      onCalls,
      totalHoldCalls,
      totalWrappedCalls,
      totalMissedCalls,
    };
  }, [runtimeData]);

  const {
    waitingCalls,
    onCalls,
    totalHoldCalls,
    totalWrappedCalls,
    totalMissedCalls,
  } = processRuntimeData();

  console.log(`Total userCallData Calls:`, userCallData);

  const handlePageClick = (event) => {
    setCurrentPage(event.selected);
  };

  const offset = currentPage * itemsPerPage;
  const currentData = historicalData.slice(offset, offset + itemsPerPage);
  return (
    <div className="bg-light">
      <div>
        <div className="container py-5">
          <div style={{ width: "100%" }}>
            <p className="current-date-time">{currentDateTime}</p>
            <Button className="top-right-button" onClick={openModalToAdd}>
              Wallboard
            </Button>
          </div>
          <Modal show={modalOpen} onHide={closeModal}>
            <Modal.Header closeButton>
              <Modal.Title>Select Campaign</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form>
                <Form.Group>
                  {campaigns.length > 0 ? (
                    <div
                      className="checkbox-group"
                      style={{ maxHeight: "200px", overflowY: "auto" }}
                    >
                      {campaigns
                        .filter(
                          (campaign) =>
                            !window.excludedTypes.includes(
                              campaign.campaignType
                            )
                        )
                        .map((campaign) => (
                          <Form.Check
                            key={campaign.campaignId}
                            type="checkbox"
                            label={campaign.campaignName}
                            value={campaign.campaignId}
                            checked={selectedCampaigns.some(
                              (selected) =>
                                selected.campaignId === campaign.campaignId &&
                                selected.campaignType ===
                                  campaign.campaignType &&
                                selected.campaignName === campaign.campaignName
                            )}
                            onChange={() =>
                              handleCheckboxChange(
                                campaign.campaignId,
                                campaign.campaignType,
                                campaign.campaignName
                              )
                            }
                          />
                        ))}
                    </div>
                  ) : (
                    <p>No Campaign available.</p>
                  )}
                </Form.Group>
              </Form>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleDone}>
                Done
              </Button>
              <Button variant="secondary" onClick={closeModal}>
                Cancel
              </Button>
            </Modal.Footer>
          </Modal>
        </div>
      </div>
      <div className="container mt-5">
        <table className="table table-bordered table-hover w-100 text-center">
          <thead>
            <tr>
              <th>Logins</th>
              <th>Idle</th>
              <th>On Call</th>
              <th>Hold</th>
              <th>Wrap Up</th>
              <th>Missed</th>
              <th>Break</th>
              <th>Waiting Calls</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{userCount || 0}</td>
              <td>{idleAgents || 0}</td>
              <td>{onCalls || 0}</td>
              <td>{totalHoldCalls}</td>
              <td>{totalWrappedCalls || 0}</td>
              <td>{totalMissedCalls || 0}</td>
              <td>{breakAgents || 0}</td>
              <td>{waitingCalls || 0}</td>
            </tr>
          </tbody>
        </table>

        <table className="table table-bordered table-hover w-100 mt-4 text-center">
          <thead>
            <tr>
              <th>Agent Name</th>
              <th>Agent Mode</th>
              <th>Campaign Name</th>
              <th>Is Working</th>
              <th>Is Ready</th>
              <th>Assigned Queue</th>
              <th>Total Duration</th>
              <th>Total Calls</th>
            </tr>
          </thead>
          <tbody>
            {currentData.map((data, dataIndex) => {
              return data.campaignUserData.map((user, userIndex) => {
                const campaignName = data.campaignInfo.campaignName;
                const agentInfo = data.agentInfo.find(
                  (info) =>
                    info.campaignId === user.campaignId &&
                    info.userId === user.userId
                );
                const agentName = agentInfo ? agentInfo.name : "Unknown";
                const queueInfo =
                  data.queueInfo &&
                  data.queueInfo.find(
                    (info) => info.campaignContextId === user.campaignId
                  );
                const userCallEntry = userCallData.find(
                  (entry) =>
                    entry.campaignId === user.campaignId &&
                    entry.userId === user.userId
                );

                // Get userTotalCalls and userTotalDuration, defaulting to 0 if not found
                const userTotalCalls = userCallEntry
                  ? userCallEntry.userTotalCalls
                  : 0;
                const userTotalDuration = userCallEntry
                  ? userCallEntry.userTotalDuration
                  : 0;

                return (
                  <tr
                    key={`user-${userIndex}`}
                    style={{ borderBottom: "10px solid white" }}
                  >
                    <td>{agentName}</td>
                    <td>{user.onAutoCall ? "On" : "Off"}</td>
                    <td>{campaignName}</td>
                    <td>{user.working ? "Yes" : "No"}</td>
                    <td>{user.ready ? "Yes" : "No"}</td>
                    <td>
                      {queueInfo ? queueInfo.queueNames : "No Queue Info"}
                    </td>
                    <td>{userTotalDuration}</td>
                    <td>{userTotalCalls}</td>
                  </tr>
                );
              });
            })}
          </tbody>
        </table>

        <div className="pagination-container">
          <ReactPaginate
            previousLabel={"previous"}
            nextLabel={"next"}
            breakLabel={"..."}
            breakClassName={"break-me"}
            pageCount={Math.ceil(historicalData.length / itemsPerPage)}
            marginPagesDisplayed={2}
            pageRangeDisplayed={5}
            onPageChange={handlePageClick}
            containerClassName={"pagination"}
            subContainerClassName={"pages pagination"}
            activeClassName={"active"}
            previousClassName={"previous"}
            nextClassName={"next"}
          />
        </div>
      </div>
    </div>
  );
};

export default Wallboard;
