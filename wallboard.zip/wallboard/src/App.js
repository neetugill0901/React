// import React from "react";
// import Wallboard from './Wallboard/Wallboard1.js';

// function App() {
//   return (
//     <div className="App">
//       < Wallboard />
//     </div>
//   );
// }

// export default App;

import React from 'react';
import { Provider } from 'react-redux';
import store from './store';
// import Wallboard from './Wallboard/Wallboard.js';
import Wallboard from './Wallboard/js/Wallboard.js';
function App() {
  return (
    <Provider store={store}>
      <Wallboard/>
    </Provider>
  );
}

export default App;
