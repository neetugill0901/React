import { createSlice } from "@reduxjs/toolkit";
import { fetchCampaigns, fetchCampUserData, fetchStatData } from "../middleware/api";

const initialState = {
  campaigns: [],
  campaignUserData: [],
  queueInfo: [],
  agentInfo: [],
  waitingCallsInfo: [],
  agentStatInfo: [],
  status: "idle",
  error: null,
};

const campaignSlice = createSlice({
  name: "campaign",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchCampaigns.pending, (state) => {
        state.loading = "loading";
      })
      .addCase(fetchCampaigns.fulfilled, (state, action) => {
        state.campaigns = action.payload;
        state.loading = "idle";
      })
      .addCase(fetchCampaigns.rejected, (state, action) => {
        state.loading = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchCampUserData.pending, (state) => {
        state.loading = "loading";
      })
      .addCase(fetchCampUserData.fulfilled, (state, action) => {
        state.campaignUserData = action.payload.campaignUserData;
        state.queueInfo = action.payload.queueInfo;
        state.agentInfo = action.payload.agentInfo;
        state.loading = "idle";
      })
      .addCase(fetchCampUserData.rejected, (state, action) => {
        state.loading = "failed";
        state.error = action.payload;
      })
      .addCase(fetchStatData.pending, (state) => {
        state.loading = "loading";
      })
      .addCase(fetchStatData.fulfilled, (state, action) => {
        state.waitingCallsInfo = action.payload.waitingCallsInfo;
        state.agentStatInfo = action.payload.agentStatInfo;
        state.loading = "idle";
      })
      .addCase(fetchStatData.rejected, (state, action) => {
        state.loading = "failed";
        state.error = action.payload;
      });
  },
});

export default campaignSlice.reducer;
