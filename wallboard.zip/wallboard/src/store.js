import { configureStore } from '@reduxjs/toolkit';
import campaignReducer from "./slice/campaignSlice";

const store = configureStore({
  reducer: {
    campaign: campaignReducer,
  },
  devTools: process.env.NODE_ENV !== 'production',
});

export default store;
