import { createAsyncThunk } from "@reduxjs/toolkit";
var client = window.AmeyoClient.init();

// Step 1: Fetch Campaign Data

export const fetchCampaigns = createAsyncThunk(
  "campaign/fetchCampaigns",
  async (value, { rejectWithValue }) => {
    //const url = "ameyorestapi/cc/campaigns/getAssigned";
    const requestObject = {
      url: window.API_URLS.FETCH_CAMPAIGNS,
      headers: {
        "content-type": "application/json",
      },
      method: "GET",
    };

    try {
      const response = await new Promise((resolve, reject) => {
        client.httpRequest
          .invokeAmeyo(requestObject)
          .then((successCallback) => {
            const data = JSON.parse(successCallback.response);
            resolve(data);
          })
          .catch((failureCallback) => {
            reject(failureCallback);
          });
      });
      return response;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// Step 2: Fetch Runtime Data

export const fetchCampUserData = createAsyncThunk(
  "campaign/fetchCampUserData",
  async ({ campaignId, campaignType, campaignName }, rejectWithValue) => {
    const requestObject = {
      url: window.API_URLS.FETCH_CAMP_USER_DATA(campaignId),
      headers: {
        "content-type": "application/json",
      },
      method: "GET",
    };

    try {
      
      const response = await new Promise((resolve, reject) => {
        client.httpRequest
          .invokeAmeyo(requestObject)
          .then((successCallback) => {
            resolve(successCallback.response);
          })
          .catch((failureCallback) => {
            reject(failureCallback);
          });
      });
      const data = JSON.parse(response);
      const filteredData = data.filter(
        (item) => item.campaignId === campaignId
      );

      if (filteredData.length > 0) {
        const campaignUserPairs = filteredData.map((item) => {
          return {
            campaignId: item.campaignId,
            userId: item.userId,
          };
        });
        let combinedData = {};
        let flag = campaignType;

        const agentNamePromises = campaignUserPairs.map(
          ({ campaignId, userId }) => fetchAgentName({ campaignId, userId })
        );
        const agentInfo = await Promise.all(agentNamePromises);
        if (flag === "Outbound Voice Campaign") {
          // Combine all data
          combinedData = {
            campaignUserData: filteredData,
            agentInfo: agentInfo,
            campaignInfo: { campaignName: campaignName },
          };
        } else if (flag === "Interactive Voice Application") {
          
          const queueInfoPromises = campaignUserPairs.map(
            ({ campaignId, userId }) =>
              fetchQueueInfoForAgent({ campaignId, userId })
          );
         
          const queueInfos = await Promise.all(queueInfoPromises);
          const allQueueInfos = queueInfos.flat();

          combinedData = {
            campaignUserData: filteredData,
            queueInfo: allQueueInfos,
            agentInfo: agentInfo,
            campaignInfo: { campaignName: campaignName },
          };
        }
        return combinedData;
      } else {
        throw new Error("No data found for the given campaignId.");
      }
    } catch (error) {
      console.error("Error fetching runtime data:", error);
      return rejectWithValue(error.message);
    }
  }
);

// Step 3: Fetch Queue Info For Agent

async function fetchQueueInfoForAgent({ userId, campaignId }) {
  const requestObject = {
    url: window.API_URLS.FETCH_QUEUE_INFO_FOR_AGENT(userId),
    headers: {
      "content-type": "application/json",
    },
    method: "GET",
  };

  let result = {
    campaignContextId: "NA",
    queueNames: [],
    queueIds: [],
    campaignContextName: "NA",
  };

  try {
    const response = await new Promise((resolve, reject) => {
      client.httpRequest
        .invokeAmeyo(requestObject)
        .then((successCallback) => {
          if (successCallback.statusCode === 200) {
            const data = JSON.parse(successCallback.response);
            const filteredData = data.filter(
              (item) =>
                item.userId === userId &&
                item.campaignContext.campaignContextId === campaignId
            );

            const queueNames = filteredData.map(
              (item) => item.agentQueue.agentQueueName
            );
            const queueIds = filteredData.map(
              (item) => item.agentQueue.agentQueueId
            );

            result = {
              campaignContextId:
                filteredData[0].campaignContext.campaignContextId,
              queueNames: queueNames.join(","),
              queueIds: queueIds,
              campaignContextName:
                filteredData[0].campaignContext.campaignContextName,
            };

            resolve(result);
          } else {
            console.log("ERROR successCallback", successCallback, result);
            resolve(result);
          }
        })
        .catch((failureCallback) => {
          reject(failureCallback);
        });
    });

    return response;
  } catch (error) {
    console.error("Error fetching queue info data:", error);
    return result;
  }
}

// Step 6: Fetch Agent Name

export async function fetchAgentName({ userId, campaignId }) {
  //const url = `ameyorestapi/cc/campaignUsers/getByCampaign?campaignId=${campaignId}`;
  const requestObject = {
    url: window.API_URLS.FETCH_AGENT_NAME(campaignId),
    headers: {
      "content-type": "application/json",
    },
    method: "GET",
  };

  let filteredData = {
    name: "NA",
    campaignId: campaignId, // Initialize with the given campaignId
  };

  try {
    const response = await new Promise((resolve, reject) => {
      client.httpRequest
        .invokeAmeyo(requestObject)
        .then((successCallback) => {
          if (successCallback.statusCode === 200) {
            const data = JSON.parse(successCallback.response);

            // Filtering data based on userId and campaignId
            const filteredStats = data.find(
              (item) =>
                item.userId.toString() === userId.toString() &&
                item.campaignId.toString() === campaignId.toString()
            );

            // Extract the name and campaignId from the user object if a match is found
            if (filteredStats && filteredStats.user) {
              filteredData.name = filteredStats.user.name;
              filteredData.campaignId = filteredStats.campaignId;
              filteredData.userId = filteredStats.userId;
            }

            resolve(filteredData);
          } else {
            console.log("ERROR successCallback", successCallback, filteredData);
            resolve(filteredData);
          }
        })
        .catch((failureCallback) => {
          console.log("ERROR failureCallback", failureCallback);
          reject(failureCallback);
        });
    });

    return response;
  } catch (error) {
    console.error("Error fetching runtime getAllStats agent data:", error);
    return filteredData;
  }
}




export const fetchStatData = createAsyncThunk(
  "campaign/fetchStatData",
  async ({ campaignId }, rejectWithValue) => {
    const requestObject = {
      url: window.API_URLS.FETCH_CAMP_USER_DATA(campaignId),
      headers: {
        "content-type": "application/json",
      },
      method: "GET",
    };

    try {
      const response = await new Promise((resolve, reject) => {
        client.httpRequest
          .invokeAmeyo(requestObject)
          .then((successCallback) => {
            resolve(successCallback.response);
          })
          .catch((failureCallback) => {
            reject(failureCallback);
          });
      });
      const data = JSON.parse(response);
      const filteredData = data.filter(
        (item) => item.campaignId === campaignId
      );

      if (filteredData.length > 0) {
        const campaignUserPairs = filteredData.map((item) => {
          return {
            campaignId: item.campaignId,
            userId: item.userId,
          };
        });
        let combinedData = {};

        // const waitingCallsPromises = campaignUserPairs.map(
        //   (campaignId) => fetchWaitingCalls(campaignId)
        // );
        // const waitingCallsInfo = await Promise.all(waitingCallsPromises);
        const waitingCallsPromises =  fetchWaitingCalls(campaignId);
        var waitingCallsInfo = await waitingCallsPromises;
        
        const agentStatPromises = campaignUserPairs.map(
          ({ campaignId, userId }) => fetchStatsAgent({ campaignId, userId })
        );
        const agentStatInfo = await Promise.all(agentStatPromises);

        combinedData = {
          waitingCallsInfo: waitingCallsInfo,
          agentStatInfo: agentStatInfo,
        };
        return combinedData;
      } else {
        throw new Error("No data found for the given campaignId.");
      }
    } catch (error) {
      console.error("Error fetching runtime data:", error);
      return rejectWithValue(error.message);
    }
  }
);

export async function fetchWaitingCalls(campaignId) {

  //const url = `ameyorestapi/voice/customerVoiceCampaignRuntimes/getByCampaign?campaignId=${campaignId}`;
  const requestObject = {
    url: window.API_URLS.FETCH_WAITING_CALLS(campaignId),
    headers: {
      "content-type": "application/json",
    },
    method: "GET",
  };

  let mappedStats = {
    ownerCrtObjectId: "NA",
    status: "NA",
    campaignId: campaignId, // With these parameter combination 1. On Call 2. Waiting Calls 3.
  };

  try {
    const response = await new Promise((resolve, reject) => {
      client.httpRequest
        .invokeAmeyo(requestObject)
        .then((successCallback) => {
          if (successCallback.statusCode === 200) {
            const data = JSON.parse(successCallback.response);
            // Filtering data based on userId and campaignId
            const filteredStats = data.filter(
              (item) => item.campaignId.toString() === campaignId.toString()
            );
            
            if (filteredStats.length > 0) {
              const mappedStats = filteredStats.map((item) => {
                return {
                  ownerCrtObjectId: item.ownerCRTObjectId,
                  campaignId: item.campaignId,
                  status: item.status,
                };
              });
              resolve(mappedStats);
            } else {
              console.log("SUCESS successCallback", successCallback, mappedStats);
              resolve(mappedStats);
            }            
        }})
        .catch((failureCallback) => {
          console.log("ERROR failureCallback", failureCallback);
          reject(failureCallback);
        });
    });
    return response;
  } catch (error) {
    console.error("Error fetching runtime getAllStats agent data:", error);
    return mappedStats;
  }
}
// Step 5: Fetch Agent Stats

export async function fetchStatsAgent({ userId, campaignId }) {
  //const url = "ameyorestapi/stats/getAllStats";
  const requestBody = JSON.stringify({
    statsName: "AgentCallStatsT2D2",
  });
  const requestObject = {
    url: window.API_URLS.FETCH_STATS_AGENT,
    headers: {
      "content-type": "application/json",
    },
    method: "POST",
    body: requestBody,
  };

  let filteredData = {
    userCampaignTalkTimeTotal: 0, // Total Duration
    totalWrappedCalls: 0, // Wrap Up
    holdCallsCount: 0, // Hold
    userCampaignCallConnectedCount: 0, // Total Calls
    userCampaignCallDropCount: 0, // Missed
    user_id : userId,
    campaign_id : campaignId,
  };

  try {
    const response = await new Promise((resolve, reject) => {
      client.httpRequest
        .invokeAmeyo(requestObject)
        .then((successCallback) => {
          if (successCallback.statusCode === 200) {
            const data = JSON.parse(successCallback.response);
            const fetchFilteredData = (data, userId, campaignId) => {
              const flattenedData = data[0].statsArr.flatMap((item) =>
                item.statsArr.map((stat) => {
                  return {
                    ...stat,
                  };
                })
              );
              for (let i = 0; i < flattenedData.length; i++) {
                if (
                  flattenedData[i].user_id.toString() === userId.toString() &&
                  flattenedData[i].campaign_id.toString() ===
                    campaignId.toString()
                ) {
                  filteredData = flattenedData[i];
                  break;
                }
              }

              if (filteredData) {
                return {
                  userCampaignTalkTimeTotal:
                    filteredData.userCampaignTalkTimeTotal,
                  totalWrappedCalls: filteredData.totalWrappedCalls,
                  holdCallsCount: filteredData.holdCallsCount,
                  userCampaignCallConnectedCount:
                    filteredData.userCampaignCallConnectedCount,
                  userCampaignCallDropCount:
                    filteredData.userCampaignCallDropedCount, 
                  user_id: filteredData.user_id,
                  campaign_id: filteredData.campaign_id,// Use the correct key name here
                };
              }

              return filteredData; // Or an empty object if no data matches
            };
            const filteredStats = fetchFilteredData(data, userId, campaignId);
            resolve(filteredStats ? filteredStats : null);
          } else {
            console.log("ERROR successCallback", successCallback, filteredData);
            resolve(filteredData);
          }
        })
        .catch((failureCallback) => {
          console.log("ERROR failureCallback", failureCallback);
          reject(failureCallback);
        });
    });
    return response;
  } catch (error) {
    console.error("Error fetching runtime getAllStats agent data:", error);
    return filteredData;
  }
}
