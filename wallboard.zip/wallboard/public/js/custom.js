var excludedTypes = [
    "Voice Blast Campaign",
    "Interaction Campaign",
    "Chat Campaign",
];

var refreshIntervals = {
	historical_intervals: 36000,
	stats_intervals:5000,
  };


var API_URLS = {
	FETCH_CAMPAIGNS: "ameyorestapi/cc/campaigns/getAssigned",
	FETCH_CAMP_USER_DATA: (campaignId) =>
	  `ameyorestapi/cc/contactCenterRuntime/getAllUserCampaignRuntimes?campaignId=${campaignId}`,
	FETCH_QUEUE_INFO_FOR_AGENT: (userId) =>
		`ameyorestapi/cc/getAllQueueInfoForAgentByUserId?userId=${userId}`,
	FETCH_AGENT_NAME: (campaignId) =>
		`ameyorestapi/cc/campaignUsers/getByCampaign?campaignId=${campaignId}`,
	FETCH_STATS_AGENT: "ameyorestapi/stats/getAllStats",
	FETCH_STATS_QUEUE: "ameyorestapi/stats/getAllStats",
	FETCH_WAITING_CALLS: (campaignId) =>
		`ameyorestapi/voice/customerVoiceCampaignRuntimes/getByCampaign?campaignId=${campaignId}`,
	
  };