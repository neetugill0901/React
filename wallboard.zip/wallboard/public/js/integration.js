if (window.attachEvent) {
	window.attachEvent('onmessage', processPostMessage);
} else {
	window.addEventListener('message', processPostMessage, false);
}



function processPostMessage(event) {
	var theObject = JSON.parse(event.data);
	if(theObject.method == 'response'){
		id=theObject.id;
		if(keyValue[id]){
			if(theObject.response==="ok"){
				keyValue[id](theObject.response, theObject.status);
			}
			else{
			keyValue[id](JSON.parse(theObject.response));
		}
			delete keyValue[id];
		}
	}
}

function genericPlugin() {

}
var keyValue = new Array();
function registerFunction(key, value) {
	keyValue[key] = value;
}
var ID = function () {
	return '_' + Math.random().toString(36).substr(2, 9);
};
genericPlugin.prototype.callRestAPI = callRest;
function doPostMessage(message) {
	var result = '';
	try {
		
		//result = "https://ameyo.salebuild.com:8887/app/#injectedHeader";
		//result = "http://ameyo.salebuild.com:8888/app/#injectedHeader";
		//result = "http://10.10.3.108:8888/app/app/#injectedHeader";
	} catch (e) {
		//result = "https://ameyo.salebuild.com:8887/app/";// if not working give crm url
		//result = "http://10.10.3.108:8888/app/";
		//result = "https://ameyo.salebuild.com:8887/app/";// if not working give crm url
	//	result = "http://ameyo.salebuild.com:8888/app/#injectedHeader";

	}
	//replace star with ip of the parent
	window.parent.postMessage(message, "*");
}

function callRest(endpoint, additionalParams,methodType,call,iframeId) {
	var id=ID();
	var theObject = {
			method : 'rest',
			endPointURL:endpoint,
			additionalParams : additionalParams,
			id:id,
			iframeId:iframeId,
			methodType:methodType
	};
	registerFunction(id,call);
	var message = JSON.stringify(theObject);
	//console.log(message);
	doPostMessage(message);
}

function getApplicationCrmUrl() {
	return 'http://10.10.2.170:8786';
	//	return 'http://10.10.2.170:8786';
	//return 'https://ameyofailover.dhiraagu.com.mv:8786';
}
function wallboardScreenSwitchTime(){
	return 10;
}
function getRuntimeRefreshTime() {
	return 5000;
}
function getStatsRefreshTime() {

	return 300000;
}

function getIframeData() {
	var urlObj ={}
	var url = window.location.search.substring(1);
	var vars = url.split("&");
	for (var i=0;i<vars.length;i++) {
      var param = vars[i].split("=");
      urlObj[param[0]] = param[1];
    }
    return urlObj;
}
function campaignVsScreenList() {
  var screen = {}
  screen['Interactive Voice Application'] = new Array('Inbound_Campaign_View');
 // screen['Outbound Voice Campaign'] = new Array('Outbound_Campaign_View');
  //screen['Interaction Campaign'] = new Array('Interaction_Campaign_View');
  return screen;
}

function callAmeyoRest(endpoint,additionalParams,methodType,callBack){
	var urlParam =  window.getIframeData();
	
               // var iframeId=urlParam.iframeId;
               // window.parent.document.getElementById(iframeId).height = '700px';


	callRest(endpoint,additionalParams,methodType,callBack,urlParam.iframeId)
}
function getContactCenterId(callBack){

	var id=ID();
	var urlParam =  window.getIframeData();
	var theObject = {
			method : 'contactCenterId',
			id:id,
			iframeId:urlParam.iframeId
			
	};
	registerFunction(id,callBack);
	var message = JSON.stringify(theObject);

	doPostMessage(message);
}

