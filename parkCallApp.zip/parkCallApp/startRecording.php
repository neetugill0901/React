<?php
	include('config.php');
	$apiUrl = $_REQUEST['apiUrl'];
	//$apiUrl = $serverPro.'://'.$serverIP.':'.$serverPort.'/ameyowebaccess/command?data='.$data.'&command=recordingStart';
	// echo $apiUrl;
	$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $apiUrl,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Cookie: JSESSIONID=CD09A31246A34D841C8AFEB597553E6C; __METADATA__=0b904f7a-e583-421e-bf94-0ef62c72752b'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
echo $response;
?>
