<?php
	$serverPro = 'http';
	$serverIP = '192.168.0.105';
	$serverPort = '8888';
	$crmPort = '8786';
?>
