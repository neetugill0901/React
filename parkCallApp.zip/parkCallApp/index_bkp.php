<?php
	include('config.php');
	$campaignId = $_REQUEST['campaignId'];
	$sessionId = $_REQUEST['sessionId'];
	$userCrtObjectId = $_REQUEST['userCrtObjectId'];
	$crtObjectId = $_REQUEST['crtObjectId'];
	$phone = $_REQUEST['phone'];
	$data = '{"crtObjectId":"'.$crtObjectId.'","userCrtObjectId":"'.$userCrtObjectId.'","sessionId":"'.$sessionId.'","campaignId":"'.$campaignId.'"}';
	// $data = urlencode($data);
	$apiUrl = $serverPro.'://'.$serverIP.':'.$serverPort.'/ameyowebaccess/command?data='.$data.'&command=';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Park Call</title>
	<style>
		.button {
		  border: none;
		  color: white;
		  padding: 15px 32px;
		  text-align: center;
		  text-decoration: none;
		  display: inline-block;
		  font-size: 16px;
		  margin: 4px 2px;
		  cursor: pointer;
		}

		.button1 {background-color: green;} /* Green */
		</style>
	<script type="text/javascript">
		function startRecording(){
		
			const queryString = window.location.search;
			
			const urlParams = new URLSearchParams(queryString);
			const campaignId = urlParams.get('campaignId');
			const queueId = urlParams.get('queueId');
			const sessionId = urlParams.get('sessionId');
			var sessionData = '"sessionId","'+sessionId+'';
			const userCRTObjectId = urlParams.get('userCrtObjectId');
			const crtObjectId = urlParams.get('crtObjectId');
			var jsonData = new Object();
			jsonData.campaignId = campaignId;
			jsonData.targetAgentQueueId = queueId;
			jsonData.transferredCRTObjectId = crtObjectId;
			jsonData.userCRTObjectId = userCRTObjectId;
			jsonData.requestId = sessionId;
			
			//call api to transfer current call
			var myHeaders = new Headers();
			myHeaders.append("sessionId",sessionId);
			myHeaders.append("Content-Type", "application/json");
			
			var raw = JSON.stringify(jsonData);

			var requestOptions = {
  				method: 'POST',
  				headers: myHeaders,
  				body: raw,
  				redirect: 'follow'
			};
			var serverData = '<?php echo $serverPro.'://'.$serverIP.':'.$serverPort; ?>';
			fetch(serverData+"/ameyorestapi/voice/transferToAgentQueue", requestOptions)
  			.then(response => response.text())
  			.then(result => console.log(result))
  			.catch(error => console.log('error', error));
		}
	</script>
</head>
<body onload="">
	<center>
		<button class="button button1" id = 'btn1' onclick="startRecording()">Park Current Call</button>
		<!-- <span id='txt1'>Recording</span> -->
	</center>
</body>
</html>
