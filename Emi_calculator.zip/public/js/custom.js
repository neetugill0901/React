var inputFields = {
    gst: '18',
    loanAmount: '',
    tenure: '',
    rate: '',
    processingFee: '',
    stampingCharges: '',
    documentCharges: '',
    insuranceCharges: '',
  };
  
var { loanAmount, tenure, rate, processingFee, stampingCharges, documentCharges, gst, insuranceCharges } = inputFields;
  