import { createSlice } from '@reduxjs/toolkit';


let {
  loanAmount,
  tenure,
  rate,
  processingFee,
  stampingCharges,
  documentCharges,
  gst,
  insuranceCharges
} = window.inputFields;

let initialState = {
  loanAmount: loanAmount,
  tenure: tenure,
  rate: rate,
  processingFee: processingFee,
  stampingCharges: stampingCharges,
  documentCharges: documentCharges,
  gst: gst,
  insuranceCharges,
  emi: 0,
  processingAmount: 0,
  finalProcessingFee: 0,
  finalDisbursal: 0,
};

const emiSlice = createSlice({
  name: 'emi',
  initialState,
  reducers: {
    setInputValues: (state, action) => {
      return { ...state, ...action.payload };
    },
    calculateValues: (state) => {
      let P = parseFloat(state.loanAmount) || 0;
      let n = parseInt(state.tenure) || 0;
      let r = (parseFloat(state.rate) || 0) / 12 / 100;
      let processingFee = parseFloat(state.processingFee) || 0;
      let stamping = parseFloat(state.stampingCharges) || 0;
      let document = parseFloat(state.documentCharges) || 0;
      let insurance = parseFloat(state.insuranceCharges) || 0;
      let type = state.type;

      const gst = parseFloat(state.gst);

      let emi = P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
      let procAmount = (P * processingFee) / 100;
      let finalProcFee = procAmount + (procAmount * gst / 100);
      let finalDisbursal = P - finalProcFee - stamping - document;

      console.log("finalDisbursal",finalDisbursal);
      console.log("insurance",insurance);
      console.log("type",type);
      
      if (type === 'PL/AL') {
        finalDisbursal += insurance;
      } else if (type === 'BL/HE') {
        finalDisbursal -= insurance;
      }
      console.log("finalDisbursal",finalDisbursal);
      state.emi = parseFloat(emi.toFixed(2));
      state.processingAmount = parseFloat(procAmount.toFixed(2));
      state.finalProcessingFee = parseFloat(finalProcFee.toFixed(2));
      state.finalDisbursal = parseFloat(finalDisbursal.toFixed(2));
    },
  },
});

export const { setInputValues, calculateValues } = emiSlice.actions;
export default emiSlice.reducer;