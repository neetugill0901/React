import React from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import { store } from './redux/store';
import { setInputValues, calculateValues } from './redux/emiSlice';
import 'materialize-css/dist/css/materialize.min.css';
import './App.css';

function EMIForm() {
  const dispatch = useDispatch();
  const emiData = useSelector((state) => state.emi);

  const handleChange = (e) => {
    dispatch(setInputValues({ [e.target.name]: e.target.value }));
  };


  const handleCalculate = () => {
    dispatch(calculateValues());
  };

  const ResultRow = ({ label, value }) => (
    <tr>
      <td>{label}</td>
      <td className="right-align">{value}</td>
    </tr>
  );
  return (
    <div className="container z-depth-2 white emi-container">
      <h6 className="center-align teal-text text-darken-3">EMI Calculator</h6>

      <div className="row">
        {[
          { name: 'loanAmount', label: 'Loan Amount' },
          { name: 'tenure', label: 'Tenure (months)' },
          { name: 'rate', label: 'Rate of Interest (%)' },
          { name: 'processingFee', label: 'Processing Fee (%)' },
          { name: 'gst', label: 'GST (%)' },
          { name: 'stampingCharges', label: 'Stamping Charges' },
          { name: 'documentCharges', label: 'Document Charges' },
          { name: 'insuranceCharges', label: 'Insurance Charges' },
          { name: 'type', label: 'Insurance Type', type: 'dropdown', options: ['PL/AL', 'BL/HE', 'Others'] },
        ].map((field) => (
          <div key={field.name} className="input-field col s12 m3">
            {field.type === 'dropdown' ? (
              <>
                <div className="custom-dropdown-wrapper">
                  <label htmlFor={field.name} className="emi-label active">
                    <span>{field.label}</span>
                  </label>
                  <select
                    name={field.name}
                    id={field.name}
                    value={emiData[field.name]}
                    onChange={handleChange}
                    className="browser-default custom-select"
                  >
                    <option value="">Select {field.label}</option>
                    {field.options.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              </>) : (
              <>
                <input
                  type="number"
                  name={field.name}
                  id={field.name}
                  value={emiData[field.name]}
                  onChange={handleChange}
                  className="emi-input"
                />
                <label htmlFor={field.name} className={emiData[field.name] ? 'active emi-label' : 'emi-label'}>
                  <span>{field.label}</span>
                </label>
              </>
            )}
          </div>
        ))}
      </div>
      <div className="center-button-container">
        <button
          onClick={handleCalculate}
          className="btn waves-effect waves-light teal darken-2 emi-button centered-calculate-button"
        >
          Calculate
        </button>
      </div>

      <div className="section">
        <h5 className="teal-text text-darken-3 results-heading">Results</h5>
        <table className="striped highlight results-table">
          <tbody>
            <ResultRow label="Loan Amount" value={`₹${parseFloat(emiData.loanAmount || 0).toLocaleString()}`} />
            <ResultRow label="EMI" value={`₹${parseFloat(emiData.emi || 0).toLocaleString()}`} />
            <ResultRow label="ROI" value={`${parseFloat(emiData.rate || 0).toLocaleString()}%`} />
            <ResultRow label="Tenure" value={`${parseFloat(emiData.tenure || 0).toLocaleString()} months`} />
            <ResultRow label="Processing Fee" value={`₹${parseFloat(emiData.finalProcessingFee || 0).toLocaleString()}`} />
            <ResultRow label="Final Disbursal" value={`₹${emiData.finalDisbursal}`} />
          </tbody>
        </table>
      </div>
    </div>

  );
}

function App() {
  return (
    <Provider store={store}>
      <EMIForm />
    </Provider>
  );
}

export default App;
